import React from "react";
import "./card-filter.css";
export const CardFilter = (props) => {
  return (
    <div className="card-filter" style={{ backgroundColor: "white" }}>
      <div className=" shadow ml-2 mt-0">
        <h3>
          <b>Filters</b>{" "}
        </h3>
      </div>
      <div className="d-flex justify-content-center">
        <b style={{ borderBottom: "2px solid grey", height: "40px" }}>
          Launch year
        </b>
      </div>

      <div className="d-flex justify-content-center mt-3 mt -2">
        <button className="mr-3" onClick={() => props.flt("2006")} href="!#">
          2006
        </button>
        <button className=" mr-2" onClick={() => props.flt("2007")}>
          2007
        </button>
      </div>
      <div className="d-flex justify-content-center mt-3 mt -2">
        <button className="mr-3" onClick={() => props.flt("2008")}>
          2008
        </button>
        <button className="mr-2" onClick={() => props.flt("2009")}>
          2009
        </button>
      </div>
      <div className="d-flex justify-content-center mt-3 mt -2">
        <button className="mr-3" onClick={() => props.flt("2010")}>
          2010
        </button>
        <button className="mr-2" onClick={() => props.flt("2011")}>
          2011
        </button>
      </div>
      <div className="d-flex justify-content-center mt-3 mt -2">
        <button className="mr-3" onClick={() => props.flt("2012")}>
          2012
        </button>
        <button className="mr-2" onClick={() => props.flt("2013")}>
          2013
        </button>
      </div>
      <div className="d-flex justify-content-center mt-3 mt -2">
        <button className="mr-3" onClick={() => props.flt("2014")}>
          2014
        </button>
        <button className="mr-2" onClick={() => props.flt("2015")}>
          2015
        </button>
      </div>
      <div className="d-flex justify-content-center mt-3 mt -2">
        <button className="mr-3" onClick={() => props.flt("2016")}>
          2016
        </button>
        <button className="mr-2" onClick={() => props.flt("2017")}>
          2017
        </button>
      </div>
      <div className="d-flex justify-content-center mt-3 mt -2">
        <button className="mr-3" onClick={() => props.flt("2018")}>
          2018
        </button>
        <button className="mr-2" onClick={() => props.flt("2019")}>
          2019
        </button>
      </div>
      <div className="d-flex ml-2 mt-3">
        <button className="mr-3" onClick={() => props.flt("2018")}>
          2020
        </button>{" "}
      </div>
      <div className="d-flex justify-content-center">
        <b
          style={{
            borderBottom: "2px solid grey",
            height: "30px",
            marginTop: "3%",
          }}
        >
          Successful Launch
        </b>
      </div>
      <div className="d-flex justify-content-center mt-3 mt -2">
        <button className="mr-3" onClick={() => props.sltf("true")}>
          true
        </button>
        <button className="mr-2" onClick={() => props.sltf("false")}>
          false
        </button>
      </div>
      <div className="d-flex justify-content-center">
        <b
          style={{
            borderBottom: "2px solid grey",
            height: "30px",
            marginTop: "3%",
          }}
        >
          Successful Landing
        </b>
      </div>
      <div className="d-flex justify-content-center mt-3 mt -2">
        <button className="mr-3" onClick={() => props.slatf("true")}>
          true
        </button>
        <button className="mr-2" onClick={() => props.slatf("false")}>
          false
        </button>
      </div>
    </div>
  );
};
